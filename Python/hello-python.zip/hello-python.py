import boto3
import datetime

def lambda_handler(event, context):
    bucket_name = "my-tf-test-bucket-prateekkonduru"
    current_day = datetime.datetime.today().weekday()
    if current_day == 6:
        s3 = boto3.client('s3')
        objects = s3.list_objects(Bucket=bucket_name)
        if 'Contents' in objects:
            for obj in objects['Contents']:
                s3.delete_object(Bucket=bucket_name, Key=obj['Key'])
            print("All objects deleted from the bucket.")
        
        else:
            print("The bucket is already empty.")
    
    else:
        print("Today is not Sunday, skipping execution.")
